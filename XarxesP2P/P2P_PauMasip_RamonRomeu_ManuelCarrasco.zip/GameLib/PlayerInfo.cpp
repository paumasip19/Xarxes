#include "PlayerInfo.h"
#include <random>


PlayerInfo::PlayerInfo()
{
}

PlayerInfo::~PlayerInfo()
{
}

Hem detectat que a vegades algun dels jugadors es desconecta de cop en Client Servidor i en el P2P al començament de la partida. En cas
de que aixo pasi, reiniciar el servidor i els clients. No sol pasar masa, pero per si un cas.

Merci!!! :)
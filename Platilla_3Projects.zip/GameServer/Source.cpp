#pragma once
#include <iostream>
#include <SFML\Graphics.hpp>
#include <SFML\Network.hpp>
#include <PlayerInfo.h>

int main()
{
	
	PlayerInfo playerInfo;
	return 0;
}